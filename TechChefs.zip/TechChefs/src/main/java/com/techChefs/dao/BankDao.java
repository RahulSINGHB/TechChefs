package com.techChefs.dao;

import java.util.List;

import com.techChefs.model.Account;
import com.techChefs.model.Bank;
import com.techChefs.model.TransactionData;

public interface BankDao {

	List<Bank> getbanklist();

	Bank getbankdata(String bankname);
	
	List<Account> getAccontData(String bankname);
	
	List<TransactionData> getTransactionData(String userId);

	Bank findBankById(String corpId);
	
}