package com.techChefs.dao;

import com.techChefs.model.User;

public interface UserDao {

	Boolean findByUsername(String userName);

	User saveUser(User userEntity);

	User loginUser(String userName, String password);

	
	
}