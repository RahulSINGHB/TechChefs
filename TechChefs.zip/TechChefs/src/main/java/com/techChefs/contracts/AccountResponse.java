package com.techChefs.contracts;

import java.util.List;

import com.techChefs.model.Account;

public class AccountResponse extends BaseResponse {
	
	private List<Account> accounts;

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> account) {
		this.accounts = account;
	}
	
	
	
	

}
