package com.techChefs.services;

import com.techChefs.contracts.AccountResponse;
import com.techChefs.contracts.BankBaseResponse;
import com.techChefs.contracts.BanksBaseResponse;
import com.techChefs.contracts.CommonBaseResponse;
import com.techChefs.contracts.TransactionDataResponse;
import com.techChefs.contracts.UserRequest;

public interface Service {

	CommonBaseResponse registerUser(UserRequest userRequest);

	CommonBaseResponse loginUser(UserRequest userRequest);

	BanksBaseResponse getbanklist();

	BankBaseResponse getbankdata(String bankname);
	
	AccountResponse getAccontData(String bankname);
	
	TransactionDataResponse getTransactionData(String accountnumber);

	CommonBaseResponse logintobank(UserRequest userRequest, String corpId);

}